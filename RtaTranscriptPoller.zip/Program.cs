﻿using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Azure.Core;
using Azure.Identity;
using Microsoft.Kiota.Abstractions;
using Microsoft.Kiota.Abstractions.Authentication;
using Microsoft.Kiota.Authentication.Azure;
using Microsoft.Kiota.Http.HttpClientLibrary;

// ── Read config from env ───────────────────────────────────────────────────────
string TENANT_ID = Environment.GetEnvironmentVariable("TENANT_ID") ?? "";
string CLIENT_ID = Environment.GetEnvironmentVariable("CLIENT_ID") ?? "";
string CLIENT_SECRET = Environment.GetEnvironmentVariable("CLIENT_SECRET") ?? "";
string RTA_MEETING_ID = Environment.GetEnvironmentVariable("RTA_MEETING_ID") ?? "";
int POLL_MS = int.TryParse(Environment.GetEnvironmentVariable("POLL_MS"), out var p) ? p : 2000;
bool VERBOSE = (Environment.GetEnvironmentVariable("VERBOSE") ?? "0") == "1";

if (string.IsNullOrWhiteSpace(TENANT_ID) ||
    string.IsNullOrWhiteSpace(CLIENT_ID) ||
    string.IsNullOrWhiteSpace(CLIENT_SECRET) ||
    string.IsNullOrWhiteSpace(RTA_MEETING_ID))
{
    Console.Error.WriteLine("Set TENANT_ID, CLIENT_ID, CLIENT_SECRET, RTA_MEETING_ID env vars.");
    return;
}

// ── Auth (app-only) via Azure.Identity + Kiota ─────────────────────────────────
var scopes = new[] { "https://graph.microsoft.com/.default" }; // app roles via /.default
var credential = new ClientSecretCredential(TENANT_ID, CLIENT_ID, CLIENT_SECRET);
var authProvider = new AzureIdentityAuthenticationProvider(credential, scopes);
var adapter = new HttpClientRequestAdapter(authProvider)
{
    BaseUrl = "https://graph.microsoft.com/beta"
};

// (Optional) quick sanity: decode a token & show roles
async Task VerifyTokenAsync()
{
    AccessToken tok = await credential.GetTokenAsync(new TokenRequestContext(scopes));
    var parts = tok.Token.Split('.');
    if (parts.Length == 3)
    {
        var payload = JsonDocument.Parse(Base64UrlDecode(parts[1])).RootElement;
        var aud = payload.TryGetProperty("aud", out var audEl) ? audEl.GetString() : null;
        Console.WriteLine($"aud: {aud}");
        if (payload.TryGetProperty("roles", out var roles))
        {
            Console.WriteLine("roles: " + string.Join(", ", roles.EnumerateArray().Select(e => e.GetString())));
        }
    }
    static byte[] Base64UrlDecode(string s)
    {
        s = s.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return Convert.FromBase64String(s);
    }
}

// ── Helper: build Kiota requests for the RTA endpoints ─────────────────────────
RequestInformation ListTranscriptsRequest(string meetingId)
{
    var ri = new RequestInformation
    {
        HttpMethod = Method.GET,
        UrlTemplate = "{+baseurl}/copilot/communications/realtimeActivityFeed/meetings/{realtimeActivityMeeting-id}/transcripts"
    };
    ri.PathParameters.Add("realtimeActivityMeeting-id", meetingId);
    ri.Headers.Add("Accept", "application/json");
    return ri;
}

RequestInformation TranscriptDetailRequest(string meetingId, string transcriptId)
{
    var ri = new RequestInformation
    {
        HttpMethod = Method.GET,
        UrlTemplate = "{+baseurl}/copilot/communications/realtimeActivityFeed/meetings/{realtimeActivityMeeting-id}/transcripts/{realTimeTranscript-id}"
    };
    ri.PathParameters.Add("realtimeActivityMeeting-id", meetingId);
    ri.PathParameters.Add("realTimeTranscript-id", transcriptId);
    ri.Headers.Add("Accept", "application/json");
    return ri;
}

// ── Helpers: safe JSON, backoff ────────────────────────────────────────────────
async Task<string?> ReadBodyAsync(Stream? s)
{
    if (s is null) return null;
    using var ms = new MemoryStream();
    await s.CopyToAsync(ms);
    var text = Encoding.UTF8.GetString(ms.ToArray());
    return string.IsNullOrWhiteSpace(text) ? null : text;
}

async Task<JsonNode?> SendJsonAsync(RequestInformation ri)
{
    try
    {
        using var stream = await adapter.SendPrimitiveAsync<Stream>(ri);
        var body = await ReadBodyAsync(stream);
        if (string.IsNullOrWhiteSpace(body)) return null;
        try { return JsonNode.Parse(body); }
        catch (JsonException)
        {
            if (VERBOSE) Console.WriteLine($"Non-JSON body (first 400 chars): {body[..Math.Min(400, body.Length)]}");
            return null;
        }
    }
    catch (Microsoft.Kiota.Abstractions.ApiException ex)
    {
        // honor Retry-After on 429/503
        if (ex.ResponseStatusCode == 429 || ex.ResponseStatusCode == 503)
        {
            var retryAfter = 2000;
            if (ex.ResponseHeaders != null &&
                ex.ResponseHeaders.TryGetValue("Retry-After", out var vals) &&
                int.TryParse(vals.FirstOrDefault(), out var secs))
                retryAfter = secs * 1000;

            Console.WriteLine($"Throttled ({ex.ResponseStatusCode}). Waiting {retryAfter}ms...");
            await Task.Delay(retryAfter);
            return await SendJsonAsync(ri);
        }
        Console.WriteLine($"HTTP error {ex.ResponseStatusCode}: {ex.Message}");
        return null;
    }
}

// ── Pretty print best-effort (beta shapes can change) ──────────────────────────
void PrintTranscript(JsonNode obj)
{
    string? Get(params string[] keys)
    {
        foreach (var k in keys)
        {
            var n = obj[k];
            if (n is not null) return n.ToString();
        }
        // nested guesses
        if (obj["metadata"]?["id"] is JsonNode mid) return mid.ToString();
        if (obj["alternatives"] is JsonArray alts && alts.FirstOrDefault()?["text"] is JsonNode t) return t.ToString();
        return null;
    }

    var id = Get("id", "transcriptId") ?? "unknown";
    var created = Get("createdDateTime", "startDateTime", "timestamp") ?? obj["metadata"]?["createdDateTime"]?.ToString();
    var lang = Get("language", "locale") ?? obj["metadata"]?["language"]?.ToString();
    var speaker = Get("speakerId") ?? obj["speaker"]?["id"]?.ToString() ?? obj["participantId"]?.ToString();
    var text = Get("text", "content", "combinedText") ?? obj["alternatives"]?.AsArray().FirstOrDefault()?["text"]?.ToString();

    var header = $"• id: {id}" +
                 (created is not null ? $" | created: {created}" : "") +
                 (lang is not null ? $" | lang: {lang}" : "") +
                 (speaker is not null ? $" | speaker: {speaker}" : "");
    Console.WriteLine(header);
    if (!string.IsNullOrWhiteSpace(text)) Console.WriteLine("  " + text);
}

// ── Main poll loop ─────────────────────────────────────────────────────────────
var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

Console.WriteLine("== RTA transcript poller (.NET + official Copilot client) ==");
Console.WriteLine($"Meeting: {RTA_MEETING_ID}");
Console.WriteLine($"Interval: {POLL_MS} ms");

await VerifyTokenAsync();

while (true)
{
    // list
    var listNode = await SendJsonAsync(ListTranscriptsRequest(RTA_MEETING_ID));

    if (listNode is null)
    {
        if (VERBOSE) Console.WriteLine("[list] empty/none yet.");
        await Task.Delay(POLL_MS);
        continue;
    }

    // handle either { "value": [...] } or a raw array
    JsonArray? items =
        listNode["value"] as JsonArray ??
        (listNode as JsonArray);

    if (items is null || items.Count == 0)
    {
        if (VERBOSE) Console.WriteLine("[list] no items.");
        await Task.Delay(POLL_MS);
        continue;
    }

    foreach (var item in items.OfType<JsonNode>())
    {
        var id = item?["id"]?.ToString()
                 ?? item?["transcriptId"]?.ToString()
                 ?? item?["metadata"]?["id"]?.ToString();

        if (string.IsNullOrWhiteSpace(id) || seen.Contains(id)) continue;
        seen.Add(id);

        Console.WriteLine("\nNEW transcript fragment:");
        PrintTranscript(item!);

        // detail
        var detailNode = await SendJsonAsync(TranscriptDetailRequest(RTA_MEETING_ID, id!));
        if (detailNode is not null)
        {
            Console.WriteLine("Detail snippet:");
            PrintTranscript(detailNode);
        }
    }

    await Task.Delay(POLL_MS);
}
